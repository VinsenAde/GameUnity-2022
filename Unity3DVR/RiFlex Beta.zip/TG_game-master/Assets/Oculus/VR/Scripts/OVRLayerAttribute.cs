﻿using UnityEngine;

/// <summary>
/// Dummy subtype of PropertyAttribute for custom inspector to use.
/// </summary>
public class OVRLayerAttribute : PropertyAttribute {
}
