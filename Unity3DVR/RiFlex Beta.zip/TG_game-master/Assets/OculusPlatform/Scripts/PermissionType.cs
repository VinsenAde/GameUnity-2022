// This file was @generated with LibOVRPlatform/codegen/main. Do not modify it!

namespace Oculus.Platform
{

  using Description = System.ComponentModel.DescriptionAttribute;

  public enum PermissionType : int
  {
    [Description("UNKNOWN")]
    Unknown,

    [Description("MICROPHONE")]
    Microphone,

    [Description("WRITE_EXTERNAL_STORAGE")]
    WriteExternalStorage,

  }

}
