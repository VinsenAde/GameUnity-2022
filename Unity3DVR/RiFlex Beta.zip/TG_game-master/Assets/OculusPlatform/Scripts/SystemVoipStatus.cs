// This file was @generated with LibOVRPlatform/codegen/main. Do not modify it!

namespace Oculus.Platform
{

  using Description = System.ComponentModel.DescriptionAttribute;

  public enum SystemVoipStatus : int
  {
    [Description("UNKNOWN")]
    Unknown,

    [Description("UNAVAILABLE")]
    Unavailable,

    [Description("SUPPRESSED")]
    Suppressed,

    [Description("ACTIVE")]
    Active,

  }

}
